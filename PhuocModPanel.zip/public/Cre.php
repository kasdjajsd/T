       </div>
                <p class="text-center text-Dark after-card">
                   <p style="font-size:200%">Mua PANEL Antiddos :</p> 
            <a href="https://t.me/HoaiPhuocDeveloper" class="text-Dark">@HoaiPhuocDeveloper</a>
            </length>
            </p>
                <main>
        <section>
            <h1>Bạn muốn có một panel thuộc bản quyền cho mod của bạn:
            <div>
                200k/tháng
                <div>
                    và
                    <div>
                        2tr/năm</h1>
<div>
    Panel có anti để chống lại những thành phần phá hoại.
    <div>
        Hosting tốc độ cao giúp nhận diện key nhanh chóng.







<div>
    
    <div>
        
        
        <div>
                <a href ="index.php"><button>Quay lại trang chủ</button></a>
            </div>
        </section>
    </main>

</body>
</html>