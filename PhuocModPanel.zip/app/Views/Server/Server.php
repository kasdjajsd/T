<?php

include('conn.php');

// for maintainece mode
$sql1 ="select * from onoff where id=11";
$result1 = mysqli_query($conn, $sql1);
$userDetails1 = mysqli_fetch_assoc($result1);

// for ftext and status
$sql2 ="select * from _ftext where id=1";
$result2 = mysqli_query($conn, $sql2);
$userDetails2 = mysqli_fetch_assoc($result2);
?>

<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>


<div class="row">
    <div class="col-lg-12">
        <div class="alert alert-person" role="alert">
            
        </div>
        <div class="card shadow-sm">
           
            <div class="card-header bg-primary text-white h6 p-3">
                
           <a class="btn btn-outline-light btn-sm" href="<?= site_url('admin/manage-users') ?>"><i class="bi bi-person-badge"></i> Quản Lý Reseller</a>
           
           <a class="btn btn-outline-light btn-sm" href="<?= site_url('keys/generate') ?>"><i class="bi bi-person-plus"></i> Tạo Key</a>
           
           
           
            </div>
            <br>
<div class="row">
    <div class="col-lg-12">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
    
    <!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
    <div class="col-lg-12">
        <div class="card mb-3">
            <div class="card-header h6 p-3 bg-primary text-white">
               Chế Độ Đóng / Mở Sever 
            </div>
            <div class="card-body">
                <?= form_open() ?>

                <input type="hidden" name="status_form" value="1">
                <div class="form-group mb-3">
                    <label for="status">Chế Độ Cũ : <font size="2" color ="#a39c9b"><?php echo $userDetails1['status']; ?></font></label>
                  
                  
  <div class="input-group mb-3">
  <div class="input-group-prepend">
  <div class="input-group-text bg-success text-white"> 
        
      <input type="radio" id="radio" name="radios" value="1" aria-label="Checkbox for following text input" REQUIRED><font size="2"> Bật</font>
      
    </div>
 </div>
 </div>

 
 <div class="input-group mb-3">
 <div class="input-group-prepend">
 <div class="input-group-text bg-danger text-white">
        
      <input type="radio" id="radio" name="radios" value="2" aria-label="Checkbox for following text input"><font size="2" REQUIRED> Tắt</font>
      
    </div>
    </div>
    </div>
    <label for="modname">Lời Nhắn: <font size="2" color ="#a39c9b"><?php echo $userDetails1['myinput']; ?></font></label>


  <div class="input-group mb-3">
  <div class="input-group-prepend">
      
    <span class="input-group-text bg-info" id="inputGroup-sizing-default">Lời Nhắn Sever</span>
  </div>
 
      <textarea class="form-control" placeholder="Ghi Lời Nhắn Khi Đóng Sever !" name = "myInput" id="myInput" id="exampleFormControlTextarea1" rows="1"></textarea>
</div>
                  
                    
                    <?php if ($validation->hasError('modname')) : ?>
                        <small id="help-modname" class="text-danger"><?= $validation->getError('modname') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group my-2">
                    <button type="submit" class="btn btn-info">Cập Nhật</button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>