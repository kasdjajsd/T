<?php

$servername = "localhost";
$username = "id21063642_phuocxthuatluong";
$password = "id21063642_phuocxthuatluonG";
$dbname = "id21063642_phuocxthuatluong";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>